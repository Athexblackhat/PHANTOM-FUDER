@echo off
java -jar "%~dp0Tools\apktool.jar" %*