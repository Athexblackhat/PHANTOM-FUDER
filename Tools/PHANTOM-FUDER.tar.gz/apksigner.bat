@echo off
java -jar "%~dp0Tools\apksigner.jar" %*